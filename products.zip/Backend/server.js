const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const port = 3000;

// Create a MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Aditya@123',
  database: 'contact_db'
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ', err);
    return;
  }
  console.log('Connected to MySQL database');
});

// Middleware to parse incoming request bodies
app.use(bodyParser.urlencoded({ extended: false }));

// Route for handling form submission
app.post('/submit-form', (req, res) => {
  const { first_name, last_name, email, phone, comments } = req.body;
  const formData = [first_name, last_name, email, phone, comments];

  // Insert the form data into the MySQL database
  connection.query('INSERT INTO contact (F_name, L_name, email, phone, msg) VALUES (?, ?, ?, ?, ?)', formData, (error, results, fields) => {
    if (error) {
      console.error('Error inserting data into MySQL: ', error);
      res.sendStatus(500);
      return;
    }
    console.log('Form data inserted successfully');
    res.sendStatus(200);
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
